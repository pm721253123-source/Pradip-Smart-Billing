package com.pradipmahata.smartbilling;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
